
"use strict";

let RM = require('./RM.js');

module.exports = {
  RM: RM,
};
