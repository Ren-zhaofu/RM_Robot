
"use strict";

let robomaster = require('./robomaster.js');

module.exports = {
  robomaster: robomaster,
};
